
Please unzip in full first.

Files:
	notebook.html
		An export of our project with all code included.
	notebook.ipynb
		The source code for our project using python/jupyter.
	notebook_no_code.html
		An export with code omitted which is less verbose making it easier to understand.
		Please see notebook.html for more detailed information such as algorithm parameters.
	breast-cancer/data.csv
		Data set used
